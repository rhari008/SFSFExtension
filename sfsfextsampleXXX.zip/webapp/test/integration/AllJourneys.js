// We cannot provide stable mock data out of the template.
// If you introduce mock data, by adding .json files in your webapp/localService/mockdata folder you have to provide the following minimum data:
// * At least 3 User in the list
// * All 3 User have at least one directReports

sap.ui.define([
	"sap/ui/test/Opa5",
	"com/sap/sfsf/sfsfextsample/test/integration/arrangements/Arrangement","com/sap/sfsf/sfsfextsample/test/integration/MasterJourney",
	"com/sap/sfsf/sfsfextsample/test/integration/NavigationJourney",
	"com/sap/sfsf/sfsfextsample/test/integration/NotFoundJourney",
	"com/sap/sfsf/sfsfextsample/test/integration/BusyJourney"
], function (Opa5, Arrangement) {
	"use strict";
	Opa5.extendConfig({
		arrangements: new Arrangement(),
		viewNamespace: "com.sap.sfsf.sfsfextsample.view.",
		autoWait: true
	});
});
