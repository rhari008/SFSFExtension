sap.ui.define([
	"sap/ui/test/Opa5",
	"com/sap/sfsf/sfsfextsample/test/integration/arrangements/Arrangement",
	"com/sap/sfsf/sfsfextsample/test/integration/NavigationJourneyPhone",
	"com/sap/sfsf/sfsfextsample/test/integration/NotFoundJourneyPhone",
	"com/sap/sfsf/sfsfextsample/test/integration/BusyJourneyPhone"
], function (Opa5, Arrangement) {
	"use strict";

	Opa5.extendConfig({
		arrangements: new Arrangement(),
		viewNamespace: "com.sap.sfsf.sfsfextsample.view.",
		autoWait: true
	});
});
